package com.example.beritabola;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Daftar dummy berita
        List<News> newsList = getDummyNews();

        // Menambahkan onClickListener untuk setiap item berita
        LinearLayout newsItem1 = findViewById(R.id.news_item_1);
        LinearLayout newsItem2 = findViewById(R.id.news_item_2);
        LinearLayout newsItem3 = findViewById(R.id.news_item_3);

        // Menampilkan detail berita saat item ditekan
        setupNewsItemClickListener(newsItem1, newsList.get(0));
        setupNewsItemClickListener(newsItem2, newsList.get(1));
        setupNewsItemClickListener(newsItem3, newsList.get(2));
    }

    // Method untuk membuat data dummy
    private List<News> getDummyNews() {
        List<News> newsList = new ArrayList<>();
        newsList.add(new News("Manchester United Kalah di Pertandingan Terkini",
                "SEBANYAK 5 penyebab Manchester United kalah 0-2 dari Newcastle United di Liga Inggris 2022-2023 akan dibahas Okezone dalam artikel ini. Manchester United takluk 0-2 dari Newcastle United dalam lanjutan Liga Inggris musim ini di Stadion Saint-James Park, Minggu 2 April 2023 malam WIB.\n" +
                        "\n" +
                        "Kekalahan Setan Merah -julukan Manchester United- akibat dua gol dari pemain Newcastle United, yakni Joseph Willock (65') dan Callum Wilson (88'). Dengan hasil ini, posisi Manchester United digeser oleh Newcastle United yang sekarang menghuni peringkat ketiga klasemen sementara Liga Inggris 2022-2023 dengan 50 poin....",
                "5 Penyebab Manchester United Kalah 0-2 dari Newcastle United di Liga Inggris 2022-2023, Nomor 1 Gara-Gara Casemiro Absen...",
                "https://i.ibb.co.com/5Ks3k38/mu.jpg"));
        newsList.add(new News("Transfer Pemain Terbaru: Real Madrid",
                "Isi konten berita transfer pemain Real Madrid...",
                "Ringkasan berita transfer Real Madrid...",
                "https://example.com/image2.jpg"));
        newsList.add(new News("Prediksi Pertandingan Indonesia Melawan Arab Saudi",
                "Isi konten berita prediksi Indonesia...",
                "Ringkasan berita prediksi Indonesia...",
                "https://example.com/image3.jpg"));
        return newsList;
    }

    // Method untuk mengatur onClickListener pada item berita
    private void setupNewsItemClickListener(LinearLayout newsItem, News news) {
        newsItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NewsDetailActivity.class);
                intent.putExtra("title", news.getTitle());
                intent.putExtra("content", news.getContent());
                intent.putExtra("imageUrl", news.getImageUrl());
                startActivity(intent);
            }
        });
    }
}
